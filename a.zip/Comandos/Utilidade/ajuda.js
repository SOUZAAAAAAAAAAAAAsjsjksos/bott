    const { EmbedBuilder, ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageActionRow} = require('discord.js')

        module.exports = {

        name: 'ajuda',
        description: 'Exibe meu painel de ajuda.',
        type: ApplicationCommandType.ChatInput,

        run: async (client, interaction, args) => {

            let embed = new EmbedBuilder()
            .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
            .setTitle(`Ajuda da ${client.user.username}`)
            .setDescription(`Olá, meu prefixo é \`/\`
            
            🎨 **Comandos Gerais:**
            \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\`
            
            🛡️ **Comandos de Moderação:**
            \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\` \`seu comando\`
            
 ___Outros:___
 > **Acesse meu website apertando** [Em breve)
 > **Me adicione em seu servidor** [Em breve)
 > **Entre no meu servidor de suporte** [Em breve]`)
            .setColor('Blue')
        
        interaction.reply({ embeds: [embed]})
        }
    }