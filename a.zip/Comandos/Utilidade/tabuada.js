const dc = require('discord.js');

module.exports = {
    name: "tabuada",
    description: "Veja a tabuada de um determinado número.",
    type: 1,
    options: [{ name: `number`, type: 4, description: `Escolha o número que você queira ver a tabuada.`, required: true, min_value: 0 }],

    run: async (client, interaction, app) => {

    await interaction.deferReply();

    const number = interaction.options.getInteger('number');

    const textTab = new dc.EmbedBuilder()
    .setTitle(`Multiplication Table 🔢`)
    .setDescription(`**Aqui está o resultado da sua tabuada de \`${number}\`:**\n\n${number} x 0= **0**\n${number} x 1= **${number}**\n${number} x 2= **${number * 2}**\n${number} x 3= **${number * 3}**\n${number} x 4= **${number * 4}**\n${number} x 5= **${number * 5}**\n${number} x 6= **${number * 6}**\n${number} x 7= **${number * 7}**\n${number} x 8= **${number * 8}**\n${number} x 9= **${number * 9}**\n${number} x 10= **${number * 10}**`)
    .setColor(`Random`)
    .setThumbnail(`https://i.pinimg.com/564x/5f/b1/f1/5fb1f1aa3e5ec1b8fab83cebfce5132c.jpg`)
    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
    .setTimestamp(new Date());

    interaction.editReply({ embeds: [textTab] });
    

}}; 
