const Discord = require("discord.js")

module.exports = {
    name: "emoji-info", 
    description: "[✨Utilidades] - Veja informações de um emoji.", 
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "emoji",
            description: "Um emoji que você deseja ver as informações.",
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },
    ],

    run: async (client, interaction) => {

        let emojiString = interaction.options.getString("emoji")
        let emoji = client.emojis.cache.find(emoji => `<:${emoji.name}:${emoji.id}>` === emojiString) || client.emojis.cache.find(emoji => emoji.name === emojiString) || client.emojis.cache.get(emojiString);

        if (!emoji) {
            interaction.reply({
                embeds: [
                    new Discord.EmbedBuilder()
                    .setColor("Red")
                    .setDescription(`**❌ - Não encontrei o emoji, siga o modelo abaixo**\n\`/emoji-info [nome]\``)
                ]
            });
        } else if (emoji) {
            try {

            if (!emoji.animated) {

                let img = `https://cdn.discordapp.com/emojis/${emoji.id}.png?size=2048`;
                let botao = new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                            .setStyle(Discord.ButtonStyle.Link)
                            .setLabel("Abrir emoji no navegador")
                            .setURL(img)
                    );

                    let embed = new Discord.EmbedBuilder()
                    .setColor("Random")
                    .setTitle("Sobre o emoji")
                    .setThumbnail(`${img}`)
                    .addFields(
                        {
                            name: ` \🔖 Nome do emoji`,
                            value: ` \ ${emoji.name}`,
                            inline: true
                        },
                        {
                            name: ` \<:idlori:1102021972893900880> ID do emoji`,
                            value: ` \ ${emoji.id}`,
                            inline: true
                        },
                        {
                            name: ` \👀 Menção`,
                            value: `\`:${emoji.name}:\``,
                            inline: true
                        },
                        {
                            name: `<:calenlori:1102022787369021520> Criado em`,
                            value: `<t:${parseInt(emoji.createdTimestamp / 1000)}>` ,
                            inline: false,
                        },
                    );

                    interaction.reply({ embeds: [embed], components: [botao] })
            } 

            else if (emoji.animated) {

                    let img = `https://cdn.discordapp.com/emojis/${emoji.id}.gif?size=2048`;
                    let botao = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setStyle(Discord.ButtonStyle.Link)
                                .setLabel("Abrir emoji no navegador")
                                .setURL(`${img}`)
                        );
    
                        let embed = new Discord.EmbedBuilder()
                        .setColor("Random")
                        .setTitle("Sobre o emoji")
                        .setThumbnail(img)
                        .addFields(
                            {
                                name: ` \🔖 Nome do emoji`,
                                value: ` \ ${emoji.name}`,
                                inline: true
                            },
                            {
                                name: ` \<:idlori:1102021972893900880> ID do emoji`,
                                value: ` \ ${emoji.id}`,
                                inline: true
                            },
                            {
                                name: ` \👀 Menção`,
                                value: `\`:${emoji.name}:\``,
                                inline: true
                            },
                            {
                                name: `<:calenlori:1102022787369021520> Criado em`,
                                value: `<t:${parseInt(emoji.createdTimestamp / 1000)}>`,
                                inline: false
                            },
                        );

                        await interaction.reply({ embeds: [embed], components: [botao] })

            }

        } catch (e) { 
            interaction.reply(`${interaction.user} Ops! Não consegui identificar o emoji.`)
        }

        }

    }
}