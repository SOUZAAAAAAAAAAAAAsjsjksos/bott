const Discord = require("discord.js");
const colors = {
  sucess: "#03fc30",
  fail: "#fc0318",
  instruction: "#035afc",
};

module.exports = {
  name: "adivinhar",
  description: "Jogue o jogo de adivinhação.",
  type: Discord.ApplicationCommandType.ChatInput,

  options: [
    {
      name: "nivel",
      description: "Escolha o nível de dificuldade.",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
      choices: [
        { name: "Muito Fácil", value: "muito_facil" },
        { name: "Fácil", value: "facil" },
        { name: "Médio", value: "medio" },
        { name: "Difícil", value: "dificil" },
        { name: "Muito Difícil", value: "muito_dificil" },
        { name: "Impossível", value: "impossivel" },
      ],
    },
  ],

  run: async (client, interaction) => {

    const nivel = interaction.options.getString("nivel");
    let tempoDuracao, numeroChances, minNumber, maxNumber;
    switch (nivel) {
      case "muito_facil":
        tempoDuracao = 60000;
        numeroChances = 5;
        maxNumber = 10;
        break;
      case "facil":
        tempoDuracao = 60000;
        numeroChances = 15;
        maxNumber = 50;
        break;
      case "medio":
        tempoDuracao = 60000;
        numeroChances = 10;
        maxNumber = 50;
        break;
      case "dificil":
        tempoDuracao = 60000;
        numeroChances = 10;
        maxNumber = 100;
        break;
      case "muito_dificil":
        tempoDuracao = 60000;
        numeroChances = 5;
        maxNumber = 100;
        break;
      case "impossivel":
        tempoDuracao = 30000;
        numeroChances = 2;
        maxNumber = 25;
        break;
      default:
        return interaction.reply({
          content: "Escolha um nível válido.",
          ephemeral: true,
        });
    }

    const numeroAleatorio = Math.floor(Math.random() * (maxNumber - 1 + 1)) + 1;

    const palpites = [];

    const filter = (response) => {
     
      if (response.author.id !== interaction.user.id) {
        return false;
      }

      const palpite = parseInt(response.content);

      if (isNaN(palpite) || palpite < minNumber || palpite > maxNumber) {
     
        if (palpites.length < numeroChances) {
          interaction.followUp({
            content: `Por favor, insira um número entre \`1\` e \`${maxNumber}\`.`,
            ephemeral: true,
          });
          response.delete();
        }
        return false;
      }

      return true;
    };

    const embed = new Discord.EmbedBuilder()
      .setColor(colors.instruction)
      .setDescription(
        `Vou pensar em um número entre \`1\` e \`${maxNumber}\`. Tente adivinhar qual é! Você tem \`${numeroChances}\` chances e \`${
          tempoDuracao / 1000
        }\` segundos para jogar.`
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });

    const collector = interaction.channel.createMessageCollector({
      filter,
      time: tempoDuracao,
    });

    collector.on("collect", async (message) => {
      const palpite = parseInt(message.content);

      const messages = await interaction.channel.messages.fetch({ limit: 2 });
      messages.forEach(async (msg) => {
        if (msg.author.id === client.user.id) {
          await msg.delete();
        }
      });

      palpites.push(palpite);

      if (palpite === numeroAleatorio) {

        const tempoGastoMilissegundos =
          Date.now() - interaction.createdTimestamp;
        const tempoGastoSegundos = Math.floor(tempoGastoMilissegundos / 1000);

        const embed = new Discord.EmbedBuilder()
          .setTitle(`\`🎉\` **Parabéns** ${interaction.user.username}`)
          .setColor(colors.sucess)
          .setDescription(
            `Você acertou o número, era \`${numeroAleatorio}\`!\nVocê usou \`${
              palpites.length
            }\` palpites e levou \`${tempoGastoSegundos}\` segundos.\nTentativas falhas: \`${
              palpites.filter((p) => p !== numeroAleatorio).join(", ") ||
              "Nenhuma, você acertou de primeira 👏"
            }\``
          )
          .setFooter({
            text: "Sinta-se à vontade para jogar novamente usando `/adivinhar`",
          });

        await interaction.followUp({ embeds: [embed], ephemeral: true });
        collector.stop();
      } else {
        if (palpites.length < numeroChances) {
       
          const chancesRestantes = numeroChances - palpites.length;
          const embed = new Discord.EmbedBuilder()
            .setColor(colors.fail)
            .setDescription(
              `Tente novamente. Dica: O número é ${
                palpite < numeroAleatorio ? "maior" : "menor"
              } do que \`${palpite}\`. Você tem mais \`${chancesRestantes}\` ${
                chancesRestantes === 1 ? "chance" : "chances"
              } restante(s).`
            );
          await interaction.followUp({ embeds: [embed], ephemeral: true });
        } else {
         
          const mensagemFinal = new Discord.EmbedBuilder()
            .setColor(colors.fail)
            .setDescription(
              `Suas \`${numeroChances}\` chances se esgotaram! O número era \`${numeroAleatorio}\`.\nNúmeros palpitados: \`${palpites.join(
                ", "
              )}\``
            );
          interaction.followUp({ embeds: [mensagemFinal], ephemeral: true });
          collector.stop();
        }
      }

      await message.delete();
    });

    collector.on("end", (collected, reason) => {
      if (reason === "time") {
        const mensagemFinal = new Discord.EmbedBuilder.setDescription(
          `Tempo esgotado! O número era \`${numeroAleatorio}\`.\nNúmeros palpitados: \`${palpites.join(
            ", "
          )}\``
        );
        interaction.followUp({ embeds: [mensagemFinal], ephemeral: true });
      }
    });
  },
};
