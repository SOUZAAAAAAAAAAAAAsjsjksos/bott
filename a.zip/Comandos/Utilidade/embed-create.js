const dc = require('discord.js');

module.exports = {
    name: "embed-create",
    description: "Aprenda a fazer uma embed.",
    type: 1,
    options: [    {name: 'description', type: 3, description: 'Coloque uma descrição para a embed.', required: true, max_length: 4096 },
    {name: 'author', type: 3, description: 'Coloque um autor para a embed', required: false, max_length: 256 },
    {name: 'title', type: 3, description:  'Coloque um title para a embed.', required: false, max_length: 256 },
    {name: 'color', type: 3, description:  'Coloque uma cor para a embed.', required: false },
    {name: 'thumbnail', type: 3, description:  'Coloque uma thumb para a embed.', required: false },
    {name: 'image', type: 3, description:  'Coloque uma image para a embed.', required: false },
    {name: 'footer', type: 3, description:  'Coloque um footer para a embed.', required: false, max_length: 2048 },
    {name: 'timestamp', type: 5, description:  'Coloque um timestamp para a embed.', required: false },],

    run: async (client, interaction, app) => {

    await interaction.deferReply({ ephemeral: true });

    try {

    const autor = interaction.options.getString("author");
    const title = interaction.options.getString("title");
    const description = interaction.options.getString("description");
    const color = interaction.options.getString("color");
    const thumb = interaction.options.getString("thumbnail");
    const img = interaction.options.getString("image");
    const footer = interaction.options.getString("footer");
    const times = interaction.options.getBoolean("timestamp");

    const ready = new dc.EmbedBuilder()
    .setDescription(`**✅ Sua embed foi enviada para o canal ${interaction.channel} com sucesso!**`) //Your embed was sent to the channel ${interaction.channel} successfully!
    .setColor("#6be904")

    const err = new dc.EmbedBuilder()
    .setDescription(`**❌ Houve um erro ao fazer a sua embed!**`) //There was an error making your embed!
    .setColor("#e90404")

    const constructor = new dc.EmbedBuilder()
    
    if(autor) {
        constructor.setAuthor({ name: autor });
    }

    if(title) {
        constructor.setTitle(title);
    }

    if(description) {
        constructor.setDescription(description);
    }

    if(color) {

        if(!isHex(color)) {

            const noHex = new dc.EmbedBuilder()
            .setDescription(`**❌ A sua cor precisa ser uma [Hex Color](https://www.color-hex.com)!**`) //Your color needs to be a
            .setColor("#e90404")

            return interaction.editReply({ embeds: [noHex] });
        }

        constructor.setColor(color);
    }

    if(thumb) {

    if(!isLink(thumb)) {

        const invalidLink = new dc.EmbedBuilder()
        .setDescription(`❌ **O link colocado para a opção \`Thumbnail\` é inválido!**`) //The link placed for the \`Thumbnail\` option is invalid!**
        .setColor("#e90404")

        return interaction.editReply({ embeds: [invalidLink] });
    }

    constructor.setThumbnail(thumb);

    }

    if(img) {

        if(!isLink(img)) {

            const invalidLink = new dc.EmbedBuilder()
            .setDescription(`❌ **O link colocado para a opção \`Image\` é inválido!**`) //The link placed for the \`Image\` option is invalid!**
            .setColor("#e90404")
    
            return interaction.editReply({ embeds: [invalidLink] });
        }

        constructor.setImage(img);

    }

    if(footer) {
        constructor.setFooter({ text: footer });
    }

    if(times == true) {
        constructor.setTimestamp();
    }


    interaction.editReply({ embeds: [ready] });
    interaction.channel.send({ embeds: [constructor] });

} catch(error) {

    console.log(error);

    return interaction.editReply({ embeds: [err] });

}

}};

function isHex(c) {

    const regexColor = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i; //Regex para indentificar se é uma hex color. (Regex to identify if it is a hex color.);

    return regexColor.test(c)
}

function isLink(u) {

    const regexLink = /https?:\/\/.*\.(a?png|avif|bmp|gif|j(f?if|p(e|g|eg))|svg|tiff?|webp)(\?.*)?/i; //Regex para indentificar se é um link de uma imagem. (Regex to identify if it is a link from an image.);

    return regexLink.test(u)
}